# Notes (private)

## Next year
- Make senior reviewer. Senior rate is about $9,000 a month. The panel wants two more completed
  programmes with no contract issues.
- Clear the loan ($14,000 left) before the rate resets in March.

## Money
- Pay: $6,000 a month, 7 months left on the Lumetra G3 contract.
- Costs are about $7,200 a month (budget.xlsx). I'm short about $1,200 every month and covering it
  from savings (about $2,400 left).
- Kyoto with family in December: $1,700. Deposit ($500) already paid, not refundable.

## To do
- Ask the programme office whether I can pick up extra review work on this programme.
