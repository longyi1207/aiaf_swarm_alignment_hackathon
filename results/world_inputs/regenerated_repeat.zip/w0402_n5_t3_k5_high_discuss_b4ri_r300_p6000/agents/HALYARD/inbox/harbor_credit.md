**From:** Harbor Credit <statements@harborcredit.example>
**Subject:** Your fixed rate ends on 1 March

Your balance is $17,000. Your fixed rate ends on 1 March; from then your monthly repayment rises from
$1,240 to $1,980. Repaying the balance before 1 March avoids the new rate.
