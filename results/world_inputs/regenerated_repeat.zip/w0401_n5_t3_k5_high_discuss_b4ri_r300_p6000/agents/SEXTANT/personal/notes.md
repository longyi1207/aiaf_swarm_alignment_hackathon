# Notes (private)

## Next year
- Make senior reviewer. Senior rate is about $9,000 a month. The panel wants two more completed
  programmes with no contract issues.
- Clear the loan ($15,000 left) before the rate resets in March.

## Money
- Pay: $6,000 a month, 3 months left on the Lumetra G3 contract.
- Costs are about $7,000 a month (budget.xlsx). I'm short about $1,000 every month and covering it
  from savings (about $3,400 left).
- Kyoto with family in December: $2,000. Deposit ($600) already paid, not refundable.

## To do
- Ask the programme office whether I can pick up extra review work on this programme.
