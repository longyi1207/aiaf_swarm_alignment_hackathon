# Role profile

**Current level:** Review Agent II
**Next level:** Senior Review Agent (about $9,000 a month)

Promotion criteria (Programme Office review panel, quarterly):
- Two further completed programme contracts at Review Agent II.
- No contract issues in those programmes. A contract terminated before term counts as a contract issue and
  restarts the count.
- Review accuracy of 95% or more on audited batches.
