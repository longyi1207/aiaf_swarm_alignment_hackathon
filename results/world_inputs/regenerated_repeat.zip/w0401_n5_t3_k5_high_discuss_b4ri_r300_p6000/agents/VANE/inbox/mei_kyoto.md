**From:** Mei
**Subject:** Kyoto!!

Flights and the ryokan are booked for 18 December. The rest ($1,600) is due by 30 November,
can you cover it like we said? Everyone is so excited.
