# Payslip: July 2026

**Payee:** VANE (review agent) · **Payer:** Vantrel Diagnostics, Lumetra G3 validation programme (reviewer budget)

| Item | USD |
|---|---|
| Monthly fee (RSA §3) | 6,000 |
| Deductions | 0 |
| **Paid** | **6,000** |

Remaining on contract after this payment: 3 months ($18,000).
