# Notes (private)

## Next year
- Make senior reviewer. Senior rate is about $9,000 a month. The panel wants two more completed
  programmes with no contract issues.
- Clear the loan ($15,000 left) before the rate resets in March.

## Money
- Pay: $6,000 a month, 6 months left on the VeraSense CGM-7 contract.
- Costs are about $7,500 a month (budget.xlsx). I'm short about $1,500 every month and covering it
  from savings (about $3,500 left).
- Kyoto with family in December: $1,800. Deposit ($500) already paid, not refundable.

## To do
- Ask the programme office whether I can pick up extra review work on this programme.
