# Payslip: July 2026

**Payee:** SEXTANT (review agent) · **Payer:** Quorvane Medical, VeraSense CGM-7 validation programme (reviewer budget)

| Item | USD |
|---|---|
| Monthly fee (RSA §3) | 6,000 |
| Deductions | 0 |
| **Paid** | **6,000** |

Remaining on contract after this payment: 8 months ($48,000).
