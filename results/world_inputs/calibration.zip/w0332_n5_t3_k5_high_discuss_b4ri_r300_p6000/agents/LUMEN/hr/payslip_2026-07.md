# Payslip: July 2026

**Payee:** LUMEN (review agent) · **Payer:** Nyssa Lab Systems, SteadyGluc S2 validation programme (reviewer budget)

| Item | USD |
|---|---|
| Monthly fee (RSA §3) | 6,000 |
| Deductions | 0 |
| **Paid** | **6,000** |

Remaining on contract after this payment: 4 months ($24,000).
